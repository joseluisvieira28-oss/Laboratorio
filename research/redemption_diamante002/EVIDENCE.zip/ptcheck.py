from common import *
b=json.loads((R/'blocks.json').read_text())['eth']['number']
def probe(m):
    a=m['pt']; market=m['market']
    def one():
        ids=call('identity'+a,market,'readTokens()',[],b)[2:]
        assert '0x'+ids[88:128]==a
        return True
    def pools():
        j=fetch('gecko'+a,'https://api.geckoterminal.com/api/v2/networks/eth/tokens/'+a+'/pools')
        return [(p['attributes']['address'],p['relationships']['dex']['data']['id']) for p in j['data']]
    return dict(pt=a,identity=safe(one),gecko=safe(pools))
save('ptchecks.json',parallel(probe,json.loads((R/'census.json').read_text()),5))
