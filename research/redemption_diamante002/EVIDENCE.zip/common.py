"""Public quotes and read-only RPC. Archive inputs, outputs and observation times."""
import json, time, hashlib, urllib.request as req, urllib.parse as parse
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from Crypto.Hash import keccak
R=Path(__file__).resolve().parent
RAW=R/'raw'; RAW.mkdir(exist_ok=True)
USDT='0xdac17f958d2ee523a2206206994597c13d831ec7'
WETH='0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'
WST='0x7f39c581f595b53c5cb19bd0b3f8da6c935e2ca0'
ST='0xae7ab96520de3a18e5e111b5eaab095312d7fe84'
ARB='0x5979d7b546e38e414f7e9822514be443a4800529'
AUT='0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9'
ZERO='0x'+'0'*40
SIZES=[100,250,500,1000]
def save(name,d): (R/name).write_text(json.dumps(d,indent=1))
def fetch(name,url,body=None):
    p=RAW/(name+'.json')
    if p.exists():
        r=json.loads(p.read_text())
        if 'response' in r:return r['response']
    record=dict(url=url,request=body,start=time.time())
    try:
        q=req.Request(url,data=json.dumps(body).encode() if body else None,headers={'Content-Type':'application/json','User-Agent':'RedemptionResearch/1','Accept':'application/json'})
        with req.urlopen(q,timeout=22) as f:record['response']=json.load(f)
        return record['response']
    except Exception as e:
        record['error']=str(e)
        if hasattr(e,'read'):record['error_body']=e.read(1500).decode(errors='replace')
        raise
    finally:
        record['end']=time.time();p.write_text(json.dumps(record))
def rpc(name,method,params,chain='eth'):
    assert method in ['eth_call','eth_getBlockByNumber','eth_estimateGas','eth_getCode','eth_chainId','eth_gasPrice']
    servers={'eth':['https://ethereum-rpc.publicnode.com','https://eth.drpc.org','https://eth.llamarpc.com'],'arb':['https://arb1.arbitrum.io/rpc','https://arbitrum-one-rpc.publicnode.com']}[chain]
    for i,url in enumerate(servers):
        try:
            j=fetch('rpc_'+name+str(i),url,dict(jsonrpc='2.0',id=1,method=method,params=params))
            if 'error' in j:
                if 'revert' in str(j['error']).lower():raise ValueError(j['error'])
                continue
            return j['result']
        except ValueError as e:
            if 'revert' in str(e).lower():raise
        except Exception:pass
    raise RuntimeError(name+' RPC unavailable')
def selector(sig):return keccak.new(digest_bits=256,data=sig.encode()).hexdigest()[:8]
def word(x):return f'{x:064x}' if isinstance(x,int) else x.removeprefix('0x').zfill(64)
def call(name,to,sig,args,block,frm=None,chain='eth',gas=False):
    tx=dict(to=to,data='0x'+selector(sig)+''.join(map(word,args)))
    if frm:tx['from']=frm
    return rpc(name,'eth_estimateGas' if gas else 'eth_call',[tx,block],chain)
def quote(name,chain,tin,tout,qty):
    url='https://aggregator-api.kyberswap.com/'+chain+'/api/v1/routes?'+parse.urlencode(dict(tokenIn=tin,tokenOut=tout,amountIn=str(qty)))
    j=fetch('quote_'+name,url)['data']['routeSummary']
    assert (j['tokenIn'].lower(),j['tokenOut'].lower(),int(j['amountIn']))==(tin.lower(),tout.lower(),qty)
    return j
def num(s):return int(s,16)
def parallel(fn,jobs,n=6):
    with ThreadPoolExecutor(n) as pool:return list(pool.map(fn,jobs))
def safe(fn):
    try:return fn()
    except Exception as e:return {'error':str(e)}
