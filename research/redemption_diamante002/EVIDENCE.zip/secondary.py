from common import *
from economic import V
def test(job):
 name,n=job;a=V[name]; q='extvault'+name+str(n)
 def work():
    entry=fetch(q,'https://aggregator-api.kyberswap.com/ethereum/api/v1/routes?'+parse.urlencode(dict(tokenIn=USDT,tokenOut=a,amountIn=n*10**6,excludedSources='erc4626')))['data']['routeSummary']
    shares=int(entry['amountOut']); final=[g[-1]['exchange'] for g in entry['route']]
    assert 'erc4626' not in final
    record=next(r for r in json.loads((R/'second/vaults_retry.json').read_text()) if r['name']==name and r['size']==n)
    block=rpc(q+'anchor','eth_getBlockByNumber',['latest',False])['number'];h=record['holder']
    preview=num(call(q+'p',a,'previewRedeem(uint256)',[shares],block))
    sim=num(call(q+'r',a,'redeem(uint256,address,address)',[shares,h,h],block,frm=h))
    assert sim==preview
    ex=quote(q+'ex','ethereum',record['asset'],USDT,sim)
    unit=float(entry['amountInUsd'])/n
    cost=(float(entry['gasUsd'])+float(ex['gasUsd'])+record['redeem_gas_usd'])/unit
    return dict(name=name,n=n,external=final,net=int(ex['amountOut'])/1e6-n-cost,gas=cost,gross=int(ex['amountOut'])/1e6-n,delta_seconds=ex['timestamp']-entry['timestamp'])
 return [name,n,safe(work)]
if __name__=='__main__':save('secondary.json',parallel(test,[(k,n) for k in V for n in SIZES],4))
