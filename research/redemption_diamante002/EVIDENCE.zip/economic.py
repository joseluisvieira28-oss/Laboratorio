from common import *
V={'sDAI':'0x83f20f44975d03b1b09e64809b757c47f942beea','sUSDS':'0xa3931d71877c0e7a3148cb7eb4463524fec27fbd','sUSDe':'0x9d39a5de30e57443bff2a8307a4256c8797a3497'}
QUEUE='0x889edc2edab5f40e902b864ad4d7ade8e412f9b1'
def block(chain):
    b=rpc('anchor_'+chain,'eth_getBlockByNumber',['latest',False],chain)
    return {k:b[k] for k in ['number','hash','timestamp','baseFeePerGas']}
blocks={c:block(c) for c in ['eth','arb']}
save('blocks.json',blocks);b=blocks['eth']['number']
def vault(job):
    name,n=job;a=V[name];key=name+str(n);r=dict(mechanism='D03',name=name,size=n,address=a)
    def work():
        entry=quote(key,'ethereum',USDT,a,n*10**6)
        shares=int(entry['amountOut'])
        def c(lbl,sig,args,**kw):return call(key+lbl,a,sig,args,b,**kw)
        asset='0x'+c('asset','asset()',[])[-40:];r.update(asset=asset,shares=shares,gas_in_usd=float(entry['gasUsd']),time_in=entry['timestamp'])
        prev=num(c('preview','previewRedeem(uint256)',[shares]))
        r.update(preview=prev,convert=num(c('convert','convertToAssets(uint256)',[shares])),max_empty=num(c('max0','maxRedeem(address)',[ZERO])))
        pools=[s['pool'] for route in entry['route'] for s in route if s['tokenOut'].lower()==a]
        dex=safe(lambda:fetch('holders_'+key,'https://api.dexscreener.com/token-pairs/v1/ethereum/'+a))
        if isinstance(dex,list):pools += [p['pairAddress'] for p in dex]
        for i,holder in enumerate(dict.fromkeys(pools)):
            if not holder.startswith('0x') or len(holder)!=42:continue
            mx=safe(lambda:num(c('max'+str(i),'maxRedeem(address)',[holder])))
            if not isinstance(mx,int) or mx<shares:continue
            r.update(holder=holder,max_holder=mx)
            sim=safe(lambda:num(c('redeem','redeem(uint256,address,address)',[shares,holder,holder],frm=holder)))
            r['redeem_call']=sim
            if isinstance(sim,int):
                r['redeem_units']=safe(lambda:num(c('gasRedeem','redeem(uint256,address,address)',[shares,holder,holder],frm=holder,gas=True)))
            break
        if name=='sUSDe':r['cooldown_seconds']=safe(lambda:num(c('cooldown','cooldownDuration()',[])))
        exit=quote(key+'exit','ethereum',asset,USDT,prev)
        end=int(exit['amountOut'])/1e6;r.update(exit_usdt=end,gross_usdt=end-n,gas_out_usd=float(exit['gasUsd']),time_out=exit['timestamp'])
        usd_per_usdt=float(entry['amountInUsd'])/n
        if 'redeem_units' in r and isinstance(r['redeem_units'],int):
            gasprice=int(entry['gasPrice']); ethusd=float(entry['gasUsd'])/(int(entry['gas'])*gasprice/1e18)
            r['redeem_gas_usd']=r['redeem_units']*gasprice/1e18*ethusd
        r['after_swap_gas_usdt']=end-n-(float(entry['gasUsd'])+float(exit['gasUsd']))/usd_per_usdt
        if 'redeem_gas_usd' in r:r['after_three_gas_usdt']=r['after_swap_gas_usdt']-r['redeem_gas_usd']/usd_per_usdt
    err=safe(work)
    if err:r.update(err)
    return r
def cross(job):
    side,n=job;key='cross'+side+str(n);src,dst=(('ethereum',USDT,WST),('arbitrum',AUT,ARB)) if side=='out' else (('arbitrum',AUT,ARB),('ethereum',USDT,WST))
    r=dict(mechanism='D02',side=side,size=n)
    def work():
        buy=quote(key,src[0],src[1],src[2],n*10**6)
        sell=quote(key+'sell',dst[0],dst[2],dst[1],int(buy['amountOut']))
        gross=int(sell['amountOut'])/1e6-n
        r.update(gross=gross,after_swap_gas=gross-(float(buy['gasUsd'])+float(sell['gasUsd']))/(float(buy['amountInUsd'])/n),t1=buy['timestamp'],t2=sell['timestamp'],shares=buy['amountOut'])
    err=safe(work)
    if err:r.update(err)
    return r
def delay(n):
    key='steth'+str(n);r=dict(mechanism='D04',size=n)
    def work():
        buy=quote(key,'ethereum',USDT,ST,n*10**6);qty=int(buy['amountOut'])
        sell=quote(key+'exit','ethereum',WETH,USDT,qty)
        immediate=quote(key+'direct','ethereum',ST,USDT,qty)
        usd=float(buy['amountInUsd'])/n;end=int(sell['amountOut'])/1e6
        r.update(steth=qty/1e18,optimistic_gross=end-n,after_swap_gas=end-n-(float(buy['gasUsd'])+float(sell['gasUsd']))/usd,immediate_after_swap_gas=int(immediate['amountOut'])/1e6-n-(float(buy['gasUsd'])+float(immediate['gasUsd']))/usd,entry_time=buy['timestamp'],exit_time=sell['timestamp'])
    err=safe(work)
    if err:r.update(err)
    return r
if __name__=='__main__':
    rows=parallel(vault,[(k,n) for k in V for n in SIZES],6)
    save('vaults.json',rows)
    save('cross.json',parallel(cross,[(side,n) for side in ['out','back'] for n in SIZES]))
    save('queue.json',parallel(delay,SIZES))
