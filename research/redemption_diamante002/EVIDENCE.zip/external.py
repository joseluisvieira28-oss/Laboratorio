from common import *
def run(rows):
    out=[]
    for r in rows:
        p=r['pt']
        out.append((p,safe(lambda:fetch('external_'+p,'https://aggregator-api.kyberswap.com/ethereum/api/v1/routes?'+parse.urlencode(dict(tokenIn=USDT,tokenOut=p,amountIn=100000000, includedSources='uniswapv2,uniswapv3,curve-stable-ng,balancer-v2'))))))
    return out
if __name__=='__main__':
    m=json.loads((R/'census.json').read_text())
    save('external_quotes.json',[v for group in parallel(run,[m[i::5] for i in range(5)],5) for v in group])
