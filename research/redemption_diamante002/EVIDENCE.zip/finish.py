import csv,json
from pathlib import Path
p=Path('.')
sec=json.load(open('secondary.json'))
with open('results.csv','a') as f,open('REPORT.md','a') as doc:
 w=csv.writer(f);doc.write('\n## Preço secundário excluindo mint\n\n| Cofre | USDT | Bruto | Gas estimado | Após gas | Estado |\n|---|---:|---:|---:|---:|---|\n')
 for a,n,d in sec:
  v=d.get('net');status='SOURCE_BLOCKED' if v is None else ('REJECTED_COSTS' if v<=0 else 'INSUFFICIENT_EVIDENCE')
  w.writerow(['D03',a+' external only',n,status,v,'Excludes mint; simulated redeem; separate quotes'])
  doc.write('| '+' | '.join(map(str,[a,n,*[round(d[k],6) if k in d else '—' for k in ['gross','gas','net']],status]))+' |\n')
