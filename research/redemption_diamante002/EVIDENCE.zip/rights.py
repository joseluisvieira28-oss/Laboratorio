from common import *
import csv
b=json.loads((R/'blocks.json').read_text())['eth']['number']
queue='0x889edc2edab5f40e902b864ad4d7ade8e412f9b1'
log='0xda0ab1e0017debcd72be8599041a2aa3ba7e740f'
def auction(label):
    key=('MCD_CLIP_'+label).encode().hex().ljust(64,'0')
    addr='0x'+call('log'+label,log,'getAddress(bytes32)',[key],b)[-40:]
    ls=call('list'+label,addr,'list()',[],b)[2:]
    return dict(ilk=label,clip=addr,active_count=int(ls[64:128],16),ids=[int(ls[i:i+64],16) for i in range(128,len(ls),64)])
save('auctions.json',[(k,safe(lambda:auction(k))) for k in ['WSTETH_A','WSTETH_B','RETH_A','ETH_A','ETH_B','ETH_C']])
def qstat(sig):return num(call('lido'+sig.split('(')[0],queue,sig,[],b))
queueinfo={k:safe(lambda:qstat(k)) for k in ['getLastRequestId()','getLastFinalizedRequestId()','unfinalizedStETH()','isPaused()','MIN_STETH_WITHDRAWAL_AMOUNT()','MAX_STETH_WITHDRAWAL_AMOUNT()']}
for k in ['getLastRequestId()','getLastFinalizedRequestId()']:
    if isinstance(queueinfo[k],int):
        s=call('status'+k.split('(')[0],queue,'getWithdrawalStatus(uint256[])',[32,1,queueinfo[k]],b)[2:]
        queueinfo[k+'_record']=[int(s[i:i+64],16) for i in range(0,len(s),64)]
save('queue_state.json',queueinfo)
