from common import *
import csv,zipfile
def read(f):return json.loads((R/f).read_text())
rows=[]
def row(d,name,size,status,value,meaning):
    rows.append(dict(mechanism=d,candidate=name,size_usdt=size,status=status,value_usdt=value,measurement=meaning))
for m in read('census.json'):
    for s in SIZES:row('D01',m['pt'],s,'REJECTED_EXECUTION',None,'No indexed external pair on DexScreener; inventory unavailable at all four sizes')
for a in read('second/cross.json'):
    carry=a['size']*((1+.0280122)**(7/365)-1) if a['side']=='back' else 0
    row('D02',a['side'],a['size'],'REJECTED_COSTS',a['after_swap_gas']-carry,'After swap gas and benchmark carry; excludes bridge fees, USDT repatriation and adverse execution')
for a in read('second/vaults_retry.json'):
    net=a.get('after_three_gas_usdt')
    row('D03',a['name'],a['size'],'REJECTED_COSTS' if net is not None and net<0 else 'INSUFFICIENT_EVIDENCE',net,'Quoted legs plus redeem eth_call and gas estimate; timestamps in vaults_retry')
for a in read('d04curve.json'):row('D04','Lido stETH',a['size'],'REJECTED_COSTS',a['upper_gross'],'At par and constant ETH price before gas, wait and slashing; actual payout unknown')
for k,v in read('second/auctions.json'):
    for s in SIZES:row('D05',k,s,'REJECTED_EXECUTION',None,'Zero open lots in list() at sampled block')
with (R/'results.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print([(a['candidate'],a['size_usdt'],a['value_usdt']) for a in rows if a['mechanism']=='D03'])
