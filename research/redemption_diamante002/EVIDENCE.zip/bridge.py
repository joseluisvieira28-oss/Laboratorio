from common import *
rows=json.loads((R/'second/cross.json').read_text())
def one(row):
    n=row['size'];back=row['side']=='back'
    params=dict(inputToken=ARB if back else WST,outputToken=WST if back else ARB,originChainId=42161 if back else 1,destinationChainId=1 if back else 42161,amount=row['shares'])
    return safe(lambda:fetch('across'+row['side']+str(n),'https://app.across.to/api/suggested-fees?'+parse.urlencode(params)))
save('fastbridge.json',parallel(one,rows,2))
