from pathlib import Path
import json,zipfile,hashlib
root=Path(__file__).resolve().parent
files=[p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.zip','.log'} and p.name!='SHA256SUMS']
dest=Path('/mnt/data');dest.mkdir(parents=True,exist_ok=True)
(root/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(root))+'\n' for p in sorted(files)))
with zipfile.ZipFile(dest/'REDEMPTION-DIAMANTE-002.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[root/'SHA256SUMS']:z.write(p,p.relative_to(root))
assert zipfile.ZipFile(dest/'REDEMPTION-DIAMANTE-002.zip').testzip() is None
