from common import *
import csv
seen=set();markets=[]
for skip in [0,100,200]:
    d=fetch('catalog'+str(skip),'https://api-v2.pendle.finance/core/v2/markets/all?limit=100&skip='+str(skip))
    for m in d['results']:
        if m['pt'] not in seen and m['expiry']<'2026-11-28' and m['chainId']==1:
            seen.add(m['pt']);markets.append(m)
            if len(markets)==100:break
    if len(markets)==100:break
def inspect(m):
    a=m['pt'].split('-')[1];name=a[2:]
    pools=safe(lambda:fetch('dex_'+name,'https://api.dexscreener.com/token-pairs/v1/ethereum/'+a))
    valid=[p for p in pools if a in [p['baseToken']['address'].lower(),p['quoteToken']['address'].lower()] and 'pendle' not in p['dexId'].lower()] if isinstance(pools,list) else []
    return dict(market=m['address'],pt=a,yt=m['yt'],sy=m['sy'],name=m['name'],chain=1,expiry=m['expiry'],accounting=m['accountingAsset'],output=m['outputTokens'],dex_ok=isinstance(pools,list),external=[dict(pair=p['pairAddress'],dex=p['dexId'],liq=p.get('liquidity'),quote=p['quoteToken'],base=p['baseToken']) for p in valid])
rows=parallel(inspect,markets,4)
save('census.json',rows)
print(len(rows),sum(r['dex_ok'] for r in rows),[(r['name'],len(r['external'])) for r in rows if r['external']])
