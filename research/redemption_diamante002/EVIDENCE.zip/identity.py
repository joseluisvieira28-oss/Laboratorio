from common import *
markets=json.loads((R/'census.json').read_text())
block=rpc('id_latest','eth_getBlockByNumber',['latest',False])['number']
def batch(i):
    part=markets[i:i+10]
    q=[dict(jsonrpc='2.0',id=j,method='eth_call',params=[dict(to=m['market'],data='0x'+selector('readTokens()')),block]) for j,m in enumerate(part)]
    data=fetch('identitybatch'+str(i),'https://ethereum-rpc.publicnode.com',q)
    byid={r['id']:r for r in data}
    return [dict(market=m['market'],pt=m['pt'],verified=byid[j].get('result','')[90:130].lower()==m['pt'][2:]) for j,m in enumerate(part)]
rows=parallel(lambda i:safe(lambda:batch(i)),range(0,len(markets),10),3)
save('identity.json',rows)
