from common import *
b=rpc('curveblock','eth_getBlockByNumber',['latest',False])['number']
quoter='0x61ffe014ba17989e743c5f6cb21bf9697530b21e'
pool='0xdc24316b9ae028f1497c275eb9192a3ea0f67022'
def uni(key,tin,tout,amt):
    r=call(key,quoter,'quoteExactInputSingle((address,address,uint256,uint24,uint160))',[tin,tout,amt,500,0],b)
    return int(r[2:66],16)
def one(n):
    t=str(n);w=uni('uentry'+t,USDT,WETH,n*10**6)
    st=num(call('curvedy'+t,pool,'get_dy(int128,int128,uint256)',[0,1,w],b))
    end=uni('uexit'+t,WETH,USDT,st)/1e6
    return dict(size=n,block=b,weth=w,steth=st,upper_gross=end-n)
save('d04curve.json',parallel(lambda n:safe(lambda:one(n)),SIZES))
