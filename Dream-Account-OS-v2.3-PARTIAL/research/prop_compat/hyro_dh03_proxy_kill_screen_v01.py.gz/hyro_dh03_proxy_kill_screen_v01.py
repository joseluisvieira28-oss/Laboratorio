from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import os
import sys
import urllib.request
import zipfile
from collections import defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path

DAY_MS = 86_400_000
MIN_MS = 60_000
INITIAL_BALANCE = 100.0
GRID = [0.10, 0.15, 0.20, 0.25, 0.30]
COST_CASES = {
    "BASE": {"rt_pct": 0.20, "half_pct": 0.10},
    "STRESS": {"rt_pct": 0.30, "half_pct": 0.15},
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def iso(ms: int | None) -> str | None:
    if ms is None:
        return None
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).isoformat().replace("+00:00", "Z")


def utc_day(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%d")


def month_key(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m")


def iter_months(start_ms: int, end_ms: int):
    d = datetime.fromtimestamp(start_ms / 1000, tz=timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    e = datetime.fromtimestamp(end_ms / 1000, tz=timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    while d <= e:
        yield d.strftime("%Y-%m")
        if d.month == 12:
            d = d.replace(year=d.year + 1, month=1)
        else:
            d = d.replace(month=d.month + 1)


@dataclass
class MinuteSeries:
    times: list[int]
    opens: list[float]
    lows: list[float]
    closes: list[float]
    index: dict[int, int]


@dataclass
class Position:
    row_index: int
    symbol: str
    entry_time: int
    exit_time: int
    entry_price: float
    exit_price: float
    initial_risk_fraction: float
    notional: float
    quantity: float
    risk_amount: float
    entry_cost: float
    exit_cost: float
    funding_cashflow: float = 0.0
    closed: bool = False


def download_and_parse_needed_minutes(source_gate: dict, resolved_rows: list[dict], cache_dir: Path) -> tuple[dict[str, MinuteSeries], dict]:
    needed = set()
    ranges_by_symbol = defaultdict(list)
    for r in resolved_rows:
        ranges_by_symbol[r["symbol"]].append((int(r["entry_time"]), int(r["exit_time"])))
        for m in iter_months(int(r["entry_time"]), int(r["exit_time"])):
            needed.add((r["symbol"], m))

    rec_map = {(r["symbol"], r["month"]): r for r in source_gate["price_records"]}
    missing = sorted(k for k in needed if k not in rec_map)
    if missing:
        raise RuntimeError(f"MISSING_FROZEN_PRICE_RECORDS:{missing[:5]} total={len(missing)}")

    cache_dir.mkdir(parents=True, exist_ok=True)
    by_symbol = defaultdict(lambda: [[], [], [], []])
    audit = {"needed_symbol_months": len(needed), "downloaded_or_cached": 0, "sha_pass": 0, "rows_loaded": 0, "symbol_months": []}

    for symbol, month in sorted(needed):
        rec = rec_map[(symbol, month)]
        dest = cache_dir / rec["archive_name"]
        if dest.exists() and sha256_file(dest) == rec["local_sha256"]:
            data = dest.read_bytes()
            source = "CACHE"
        else:
            with urllib.request.urlopen(rec["archive_url"], timeout=120) as resp:
                data = resp.read()
            got = sha256_bytes(data)
            if got != rec["local_sha256"]:
                raise RuntimeError(f"SOURCE_VERSION_DRIFT_BLOCKED:{symbol}:{month}:{got}:{rec['local_sha256']}")
            dest.write_bytes(data)
            source = "DOWNLOAD"
        audit["downloaded_or_cached"] += 1
        audit["sha_pass"] += 1
        expected_name = rec["archive_name"].replace(".zip", ".csv")
        with zipfile.ZipFile(io.BytesIO(data), "r") as zf:
            names = zf.namelist()
            if expected_name not in names:
                raise RuntimeError(f"ZIP_MEMBER_MISSING:{expected_name}:{names[:3]}")
            with zf.open(expected_name, "r") as raw:
                txt = io.TextIOWrapper(raw, encoding="utf-8")
                reader = csv.reader(txt)
                n = 0
                for row in reader:
                    if not row:
                        continue
                    try:
                        t = int(row[0])
                    except ValueError:
                        continue
                    # Only retain minutes intersecting at least one resolved position for this symbol.
                    keep = False
                    for a, b in ranges_by_symbol[symbol]:
                        if a <= t <= b:
                            keep = True
                            break
                    if not keep:
                        continue
                    o = float(row[1]); lo = float(row[3]); c = float(row[4])
                    by_symbol[symbol][0].append(t)
                    by_symbol[symbol][1].append(o)
                    by_symbol[symbol][2].append(lo)
                    by_symbol[symbol][3].append(c)
                    n += 1
                audit["rows_loaded"] += n
                audit["symbol_months"].append({"symbol": symbol, "month": month, "source": source, "rows_retained": n, "sha256": rec["local_sha256"]})

    out = {}
    for symbol, cols in by_symbol.items():
        ts, op, lo, cl = cols
        # Deduplicate exact timestamps across adjacent archive handling (should not occur) and sort.
        combined = sorted(zip(ts, op, lo, cl), key=lambda x: x[0])
        dedup = []
        prev = None
        for item in combined:
            if item[0] == prev:
                raise RuntimeError(f"DUPLICATE_MINUTE:{symbol}:{item[0]}")
            prev = item[0]
            dedup.append(item)
        ts = [x[0] for x in dedup]; op = [x[1] for x in dedup]; lo = [x[2] for x in dedup]; cl = [x[3] for x in dedup]
        out[symbol] = MinuteSeries(ts, op, lo, cl, {t:i for i,t in enumerate(ts)})
    return out, audit


def load_funding(source_dir: Path) -> dict[str, list[tuple[int, float]]]:
    out = {}
    for p in sorted((source_dir / "canonical_funding").glob("*_funding.csv")):
        sym = p.name.replace("_funding.csv", "")
        vals = []
        with p.open(newline="", encoding="utf-8") as f:
            rd = csv.DictReader(f)
            for r in rd:
                vals.append((int(r["funding_time_ms"]), float(r["funding_rate"])))
        out[sym] = vals
    return out


def validate_ledger_funding(resolved_rows: list[dict], funding: dict[str, list[tuple[int,float]]]) -> dict:
    max_abs = 0.0
    mismatches = []
    for i, r in enumerate(resolved_rows):
        vals = [rate for t, rate in funding[r["symbol"]] if int(r["entry_time"]) < t < int(r["exit_time"])]
        calc = -sum(vals)
        diff = abs(calc - float(r["funding_return"]))
        max_abs = max(max_abs, diff)
        if diff > 1e-12 or len(vals) != int(r["funding_event_count"]):
            mismatches.append({"i": i, "symbol": r["symbol"], "calc": calc, "ledger": r["funding_return"], "count_calc": len(vals), "count_ledger": r["funding_event_count"]})
    if mismatches:
        raise RuntimeError(f"FUNDING_LEDGER_MISMATCH:{mismatches[:3]}")
    return {"validated_trade_count": len(resolved_rows), "max_abs_return_diff": max_abs, "mismatch_count": 0}


def price_at(series: MinuteSeries, t: int, field: str) -> float:
    idx = series.index.get(t)
    if idx is None:
        raise RuntimeError(f"MISSING_REQUIRED_MINUTE:{t}")
    if field == "open": return series.opens[idx]
    if field == "low": return series.lows[idx]
    if field == "close": return series.closes[idx]
    raise ValueError(field)


def equity(balance: float, positions: dict[int, Position], series_map: dict[str, MinuteSeries], t: int, field: str) -> float:
    e = balance
    for p in positions.values():
        px = price_at(series_map[p.symbol], t, field)
        e += p.quantity * (px - p.entry_price)
    return e


def simulate_cell(resolved_rows: list[dict], series_map: dict[str, MinuteSeries], funding: dict[str, list[tuple[int,float]]], risk_pct: float, cost_case: str) -> dict:
    cost_half = COST_CASES[cost_case]["half_pct"] / 100.0
    rows_sorted = sorted(list(enumerate(resolved_rows)), key=lambda x: (int(x[1]["entry_time"]), x[1]["symbol"]))
    entries = defaultdict(list); exits = defaultdict(list); fund_events = defaultdict(list)
    for ridx, r in rows_sorted:
        entries[int(r["entry_time"])].append((ridx, r))
        exits[int(r["exit_time"])].append((ridx, r))
        for ft, rate in funding[r["symbol"]]:
            if int(r["entry_time"]) < ft < int(r["exit_time"]):
                fund_events[(ft // MIN_MS) * MIN_MS].append((ridx, r["symbol"], rate))

    first_entry = min(entries)
    last_exit = max(exits)
    # Active-minute set: exact minutes covered by at least one resolved position, plus event minutes.
    active_minutes = set()
    for r in resolved_rows:
        a = int(r["entry_time"]); b = int(r["exit_time"])
        # all required source minutes are complete under Phase5 source gate
        active_minutes.update(range(a, b + MIN_MS, MIN_MS))
    active_minutes.update(entries.keys()); active_minutes.update(exits.keys()); active_minutes.update(fund_events.keys())
    times = sorted(active_minutes)

    balance = INITIAL_BALANCE
    positions: dict[int, Position] = {}
    trade_results = {}
    day_realized = defaultdict(float)
    day_entries = defaultdict(int)
    day_qualifying_closes = defaultdict(int)
    qualifying_days = set()
    last_close_ms = None
    pass_time = None; breach_time = None; breach_reason = None
    close_mark_min_equity = float("inf"); low_mark_min_equity = float("inf")
    close_mark_min_t = None; low_mark_min_t = None
    daily_floor = None; current_day = None; daily_start_equity = None
    dd_breach_close = None; dd_breach_low_diag = None
    maxloss_breach_close = None; maxloss_breach_low_diag = None
    max_open_positions = 0; max_open_notional = 0.0; max_margin_pct = 0.0
    max_open_notional_multiple = 0.0
    consistency_ratio_at_pass = None

    # To evaluate inactivity during flat gaps as well as active intervals, check before every event/minute.
    inactivity_anchor = first_entry

    for t in times:
        if pass_time is not None or breach_time is not None:
            break
        # If the challenge survived a >30d no-close interval, breach occurred before this timestamp.
        anchor = last_close_ms if last_close_ms is not None else inactivity_anchor
        if t - anchor > 30 * DAY_MS:
            breach_time = anchor + 30 * DAY_MS + MIN_MS
            breach_reason = "INACTIVITY_GT_30D"
            break

        day = utc_day(t)
        if day != current_day:
            # Starting equity at UTC day boundary uses minute open BEFORE events at that minute.
            current_day = day
            daily_start_equity = equity(balance, positions, series_map, t, "open") if positions else balance
            daily_floor = daily_start_equity - 4.0

        # Entries: size from pre-entry account equity at minute open and before entry cost.
        if t in entries:
            for ridx, r in entries[t]:
                pre_eq = equity(balance, positions, series_map, t, "open") if positions else balance
                risk_amount = pre_eq * (risk_pct / 100.0)
                irf = float(r["initial_risk_fraction"])
                notional = risk_amount / irf
                qty = notional / float(r["entry_price"])
                e_cost = notional * cost_half
                x_cost = notional * cost_half
                balance -= e_cost
                positions[ridx] = Position(ridx, r["symbol"], int(r["entry_time"]), int(r["exit_time"]), float(r["entry_price"]), float(r["exit_price"]), irf, notional, qty, risk_amount, e_cost, x_cost)
                day_entries[day] += 1

        # Funding after daily reset and after any entry at exact minute; event must be strictly after entry anyway.
        if t in fund_events:
            for ridx, sym, rate in fund_events[t]:
                p = positions.get(ridx)
                if p is None:
                    continue
                cash = -float(rate) * p.notional
                balance += cash
                p.funding_cashflow += cash

        # Exits use frozen exit price and then remove position.
        if t in exits:
            for ridx, r in exits[t]:
                p = positions.get(ridx)
                if p is None:
                    raise RuntimeError(f"EXIT_WITHOUT_POSITION:{ridx}:{r['symbol']}:{t}")
                price_pnl = p.quantity * (p.exit_price - p.entry_price)
                balance += price_pnl
                balance -= p.exit_cost
                net = price_pnl + p.funding_cashflow - p.entry_cost - p.exit_cost
                gross_return = (p.exit_price - p.entry_price) / p.entry_price
                trade_results[ridx] = {
                    "symbol": p.symbol,
                    "entry_time": p.entry_time,
                    "exit_time": p.exit_time,
                    "notional": p.notional,
                    "risk_amount": p.risk_amount,
                    "price_pnl": price_pnl,
                    "funding_cashflow": p.funding_cashflow,
                    "entry_cost": p.entry_cost,
                    "exit_cost": p.exit_cost,
                    "net_pnl": net,
                    "net_r_on_entry_risk": net / p.risk_amount if p.risk_amount else None,
                    "gross_price_return": gross_return,
                }
                day_realized[day] += net
                if p.notional >= 5.0 and abs(net) / p.notional >= 0.01:
                    day_qualifying_closes[day] += 1
                if net < -3.0:
                    breach_time = t; breach_reason = "SINGLE_POSITION_REALIZED_LOSS_GT_3PCT_INITIAL"
                del positions[ridx]
                last_close_ms = t
            if day_entries[day] > 0 and day_qualifying_closes[day] > 0:
                qualifying_days.add(day)

        # Mark-to-market after current minute events.
        eq_close = equity(balance, positions, series_map, t, "close") if positions else balance
        eq_low = equity(balance, positions, series_map, t, "low") if positions else balance
        if eq_close < close_mark_min_equity:
            close_mark_min_equity = eq_close; close_mark_min_t = t
        if eq_low < low_mark_min_equity:
            low_mark_min_equity = eq_low; low_mark_min_t = t
        if daily_floor is not None and eq_close <= daily_floor and dd_breach_close is None:
            dd_breach_close = {"time": t, "equity": eq_close, "floor": daily_floor, "day_start_equity": daily_start_equity}
            breach_time = t; breach_reason = "SWING_DAILY_DRAWDOWN_CLOSE_MARK"
        if daily_floor is not None and eq_low <= daily_floor and dd_breach_low_diag is None:
            dd_breach_low_diag = {"time": t, "equity": eq_low, "floor": daily_floor, "day_start_equity": daily_start_equity}
        if eq_close <= 94.0 and maxloss_breach_close is None:
            maxloss_breach_close = {"time": t, "equity": eq_close}
            breach_time = t; breach_reason = "MAXIMUM_LOSS_CLOSE_MARK"
        if eq_low <= 94.0 and maxloss_breach_low_diag is None:
            maxloss_breach_low_diag = {"time": t, "equity": eq_low}

        max_open_positions = max(max_open_positions, len(positions))
        total_notional = sum(p.notional for p in positions.values())
        max_open_notional = max(max_open_notional, total_notional)
        max_open_notional_multiple = max(max_open_notional_multiple, total_notional / INITIAL_BALANCE)
        max_margin_pct = max(max_margin_pct, (total_notional / 10.0) / INITIAL_BALANCE * 100.0)

        if breach_time is not None:
            break

        # Pass can only occur after realized outcomes; evaluate every minute harmlessly.
        total_net_realized = sum(day_realized.values())
        pos_days = [v for v in day_realized.values() if v > 0]
        total_positive = sum(pos_days)
        best_day = max(pos_days) if pos_days else 0.0
        consistency_ratio = (best_day / total_positive) if total_positive > 0 else None
        if total_net_realized >= 10.0 and len(qualifying_days) >= 5 and consistency_ratio is not None and consistency_ratio <= 0.40:
            pass_time = t
            consistency_ratio_at_pass = consistency_ratio
            break

    # If no pass/breach during active minutes, inactivity may occur before end of historical source window.
    if pass_time is None and breach_time is None:
        anchor = last_close_ms if last_close_ms is not None else inactivity_anchor
        source_end = int(datetime(2024,12,31,23,59,tzinfo=timezone.utc).timestamp()*1000)
        if source_end - anchor > 30 * DAY_MS:
            breach_time = anchor + 30 * DAY_MS + MIN_MS
            breach_reason = "INACTIVITY_GT_30D"

    total_net_realized = sum(day_realized.values())
    pos_days = [v for v in day_realized.values() if v > 0]
    total_positive = sum(pos_days)
    best_day = max(pos_days) if pos_days else 0.0
    consistency_ratio = (best_day / total_positive) if total_positive > 0 else None

    if breach_time is not None and (pass_time is None or breach_time <= pass_time):
        label = "OBVIOUS_PROXY_BREACH"
    elif pass_time is not None:
        label = "NO_OBVIOUS_PROXY_BREACH_BUT_EXACT_REPLAY_STILL_BLOCKED"
    else:
        label = "PROXY_INSUFFICIENT"

    return {
        "risk_pct_per_1R": risk_pct,
        "cost_case": cost_case,
        "label": label,
        "pass_time_utc": iso(pass_time),
        "breach_time_utc": iso(breach_time),
        "breach_reason": breach_reason,
        "ending_balance_at_stop": balance,
        "total_net_realized_pnl_at_stop": total_net_realized,
        "qualifying_trading_days_at_stop": len(qualifying_days),
        "qualifying_days": sorted(qualifying_days),
        "positive_realized_day_profit_total": total_positive,
        "best_positive_realized_day_profit": best_day,
        "best_day_share_positive_profit": consistency_ratio,
        "consistency_ratio_at_pass": consistency_ratio_at_pass,
        "min_close_mark_equity": close_mark_min_equity,
        "min_close_mark_equity_time_utc": iso(close_mark_min_t),
        "min_low_mark_equity_diagnostic": low_mark_min_equity,
        "min_low_mark_equity_time_utc": iso(low_mark_min_t),
        "daily_drawdown_close_mark_breach": None if dd_breach_close is None else {**dd_breach_close, "time_utc": iso(dd_breach_close["time"])},
        "daily_drawdown_low_mark_diagnostic": None if dd_breach_low_diag is None else {**dd_breach_low_diag, "time_utc": iso(dd_breach_low_diag["time"])},
        "maximum_loss_close_mark_breach": None if maxloss_breach_close is None else {**maxloss_breach_close, "time_utc": iso(maxloss_breach_close["time"])},
        "maximum_loss_low_mark_diagnostic": None if maxloss_breach_low_diag is None else {**maxloss_breach_low_diag, "time_utc": iso(maxloss_breach_low_diag["time"])},
        "max_simultaneous_positions": max_open_positions,
        "max_open_notional_initial_balance_multiple": max_open_notional_multiple,
        "max_margin_pct_initial_balance_at_10x": max_margin_pct,
        "funded_2x_notional_diagnostic_breach": max_open_notional_multiple > 2.0,
        "funded_25pct_margin_diagnostic_breach_at_10x": max_margin_pct > 25.0,
        "trades_closed_before_stop": len(trade_results),
    }


def main(argv):
    if len(argv) != 4:
        raise SystemExit("usage: runner SOURCE_DIR EXEC_DIR OUT_DIR")
    source_dir = Path(argv[1]); exec_dir = Path(argv[2]); out_dir = Path(argv[3]); out_dir.mkdir(parents=True, exist_ok=True)
    ledger_path = exec_dir / "DH-03-HO1_LEDGER.json"
    if sha256_file(ledger_path) != "ec4e5dbc8d95a73d4eb9db55f4e1c0f264dba7eb724cbb7424f2c034a3a7eebd":
        raise RuntimeError("LEDGER_SHA_MISMATCH")
    all_rows = json.loads(ledger_path.read_text())
    resolved = [r for r in all_rows if not r.get("execution_path_unresolved") and r.get("exit_time") is not None]
    if len(all_rows) != 148 or len(resolved) != 146:
        raise RuntimeError(f"LEDGER_COUNT_DRIFT:{len(all_rows)}:{len(resolved)}")
    gate = json.loads((source_dir / "HTF_DIAMOND_HUNT_001_PHASE5_SOURCE_GATE_V0.1.json").read_text())
    if gate["status"] != "SOURCE_DATA_PASS" or gate["source_fingerprint"] != "d1a95d51d99eba0bd5f66e91d75ddcd175f7a84d954ba28a44c2dcd39ef4c5cb":
        raise RuntimeError("SOURCE_GATE_DRIFT")
    if gate.get("access_2025_performed") or gate.get("access_2026_performed"):
        raise RuntimeError("LOCKED_YEAR_SOURCE_GATE_VIOLATION")
    funding = load_funding(source_dir)
    funding_validation = validate_ledger_funding(resolved, funding)
    series_map, source_audit = download_and_parse_needed_minutes(gate, resolved, out_dir / "minute_cache")

    # Exact source coverage sanity: every required minute for every resolved trade must exist.
    missing_required = []
    for r in resolved:
        s = series_map[r["symbol"]]
        for t in (int(r["entry_time"]), int(r["exit_time"])):
            if t not in s.index:
                missing_required.append((r["symbol"], t))
    if missing_required:
        raise RuntimeError(f"MISSING_ENTRY_EXIT_MINUTES:{missing_required[:5]}")

    cells = []
    for risk in GRID:
        for cost_case in ("BASE", "STRESS"):
            print("RUN_CELL", risk, cost_case, flush=True)
            cells.append(simulate_cell(resolved, series_map, funding, risk, cost_case))

    correlation = []
    for risk in GRID:
        for n in [2,3,4,6]:
            loss = n * risk
            correlation.append({
                "risk_pct_per_1R": risk,
                "concurrent_full_R_losses": n,
                "nominal_loss_pct_initial_equity": loss,
                "below_4pct_daily_amount": loss < 4.0,
                "below_6pct_max_loss_amount": loss < 6.0,
            })

    labels = {f"{c['risk_pct_per_1R']:.2f}_{c['cost_case']}": c["label"] for c in cells}
    survivors = [c for c in cells if c["label"] == "NO_OBVIOUS_PROXY_BREACH_BUT_EXACT_REPLAY_STILL_BLOCKED"]
    failures = [c for c in cells if c["label"] == "OBVIOUS_PROXY_BREACH"]
    insufficient = [c for c in cells if c["label"] == "PROXY_INSUFFICIENT"]
    if survivors:
        campaign = "PROXY_SURVIVORS_EXIST_EXACT_HYRO_REPLAY_STILL_BLOCKED"
    elif failures and not insufficient:
        campaign = "ALL_PROXY_CELLS_OBVIOUSLY_BREACH"
    else:
        campaign = "PROXY_SCREEN_INSUFFICIENT_OR_MIXED_NO_SURVIVOR"

    out = {
        "document_id": "PROP_COMPAT_001A_HYRO_DH03_PROXY_KILL_SCREEN_RESULT_V0.1",
        "campaign_id": "PROP-COMPAT-001A",
        "setup_id": "DH-03-HO1",
        "prop_program": "HYROTRADER_ONE_STEP_SWING_CLEO",
        "status": "PROXY_KILL_SCREEN_COMPLETE_NON_DECISIONAL",
        "authority": "PROP_COMPAT_001_HYRO_DH03_PROXY_KILL_SCREEN_PROTOCOL_V0.1",
        "governance": {
            "official_phase3_risk_grid_run": False,
            "exact_prop_replay_run": False,
            "challenge_purchase_authorized": False,
            "live_trading_authorized": False,
            "setup_rules_changed": False,
            "post_outcome_tuning": False,
            "merge_to_main": False,
        },
        "source_audit": source_audit,
        "funding_validation": funding_validation,
        "ledger": {"all_rows": len(all_rows), "resolved_rows": len(resolved), "sha256": sha256_file(ledger_path)},
        "cells": cells,
        "cell_labels": labels,
        "correlation_stress": correlation,
        "summary": {
            "survivor_cell_count": len(survivors),
            "obvious_breach_cell_count": len(failures),
            "insufficient_cell_count": len(insufficient),
            "campaign_proxy_classification": campaign,
            "exact_hyro_compatibility_remains_blocked": True,
            "best_risk_size_selected": False,
        },
    }
    # Fingerprint excludes itself.
    canonical = json.dumps(out, sort_keys=True, separators=(",", ":")).encode()
    out["fingerprint_sha256"] = hashlib.sha256(canonical).hexdigest()
    (out_dir / "PROP_COMPAT_001A_HYRO_DH03_PROXY_KILL_SCREEN_RESULT_V0.1.json").write_text(json.dumps(out, indent=2, sort_keys=True))
    # Compact CSV for all cells.
    fields = ["risk_pct_per_1R","cost_case","label","pass_time_utc","breach_time_utc","breach_reason","ending_balance_at_stop","total_net_realized_pnl_at_stop","qualifying_trading_days_at_stop","best_day_share_positive_profit","min_close_mark_equity","min_low_mark_equity_diagnostic","max_simultaneous_positions","max_open_notional_initial_balance_multiple","max_margin_pct_initial_balance_at_10x","trades_closed_before_stop"]
    with (out_dir / "PROP_COMPAT_001A_HYRO_DH03_PROXY_KILL_SCREEN_CELLS_V0.1.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for c in cells:
            w.writerow({k:c.get(k) for k in fields})
    print(json.dumps(out["summary"], sort_keys=True), flush=True)
    print("FINGERPRINT", out["fingerprint_sha256"], flush=True)
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
