import csv, io, zipfile, re
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict
from .guards import GateError

DISCOVERY_FIRST_MS=1609459200000     # 2021-01-01 00:00:00 UTC
DISCOVERY_AFTER_MS=1735689600000     # 2025-01-01 00:00:00 UTC
BLOCK_2026_MS=1767225600000          # 2026-01-01 00:00:00 UTC

ALIASES={
    "open_time":{"open_time","opentime","timestamp","time","start_time"},
    "open":{"open"},"high":{"high"},"low":{"low"},"close":{"close"},"volume":{"volume","base_volume"}
}

def _norm(x): return re.sub(r"[^a-z0-9_]+","",x.strip().lower().replace(" ","_"))

def discover_market_files(root,symbols):
    root=Path(root); out=[]; ups=[s.upper() for s in symbols]
    for p in root.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in {".csv",".zip"}: continue
        name=str(p).upper()
        m=[s for s in ups if s in name]
        if m: out.append((m[0],p))
    return sorted(out,key=lambda x:(x[0],str(x[1])))


def files_from_research_index(dataset_workspace,index_path,symbols):
    """
    Resolve exactly one canonical source file per symbol/month from a frozen
    RESEARCH_INPUT_INDEX. Discovery opens only 2021-01 through 2024-12 entries.
    2025 entries may exist in the index but are never opened or stat'ed here.
    """
    import json
    workspace=Path(dataset_workspace)
    idxp=Path(index_path)
    if not idxp.is_absolute():
        idxp=workspace/idxp
    if not idxp.exists():
        raise GateError(f"RESEARCH_INPUT_INDEX_NOT_FOUND:{idxp}")
    rows=json.loads(idxp.read_text(encoding="utf-8"))
    if not isinstance(rows,list) or len(rows)!=600:
        raise GateError(f"RESEARCH_INPUT_INDEX_MUST_HAVE_600_SLOTS:{len(rows) if isinstance(rows,list) else 'NON_LIST'}")
    wanted=set(s.upper() for s in symbols)
    seen=set(); files=[]
    per_symbol={s:0 for s in wanted}
    for r in rows:
        symbol=str(r.get("symbol","")).upper()
        month=str(r.get("month",""))
        classification=r.get("classification")
        key=(symbol,month)
        if key in seen: raise GateError(f"RESEARCH_INPUT_INDEX_DUPLICATE_SLOT:{symbol}:{month}")
        seen.add(key)
        if classification!="PASS":
            raise GateError(f"RESEARCH_INPUT_INDEX_NON_PASS_SLOT:{symbol}:{month}:{classification}")
        if symbol not in wanted:
            continue
        # Discovery firewall: ignore 2025 entries without touching their file paths.
        if not ("2021-01" <= month <= "2024-12"):
            continue
        rel=r.get("relative_source_path")
        if not rel:
            raise GateError(f"RESEARCH_INPUT_INDEX_PATH_MISSING:{symbol}:{month}")
        p=workspace/Path(rel)
        if not p.exists():
            raise GateError(f"RESEARCH_INPUT_FILE_NOT_FOUND:{symbol}:{month}:{p}")
        files.append((symbol,p,month,r.get("source_type","UNKNOWN")))
        per_symbol[symbol]+=1
    if len(files)!=480:
        raise GateError(f"DISCOVERY_INDEX_MUST_RESOLVE_480_MONTHS:{len(files)}")
    bad={s:n for s,n in per_symbol.items() if n!=48}
    if bad:
        raise GateError(f"DISCOVERY_INDEX_PER_SYMBOL_MONTH_COUNT_INVALID:{bad}")
    return sorted(files,key=lambda x:(x[0],x[2]))

def _streams(path):
    if path.suffix.lower()==".csv":
        with open(path,"r",encoding="utf-8-sig",newline="") as f: yield f
    else:
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                if info.filename.lower().endswith(".csv"):
                    with z.open(info) as raw:
                        yield io.TextIOWrapper(raw,encoding="utf-8-sig",newline="")

def _rows(stream):
    reader=csv.reader(stream); first=next(reader,None)
    if first is None:return
    names=[_norm(x) for x in first]
    header=any(n in ALIASES["open_time"] for n in names)
    if header:
        idx={}
        for k,aa in ALIASES.items():
            for i,n in enumerate(names):
                if n in aa: idx[k]=i; break
        need=set(ALIASES)
        if not need.issubset(idx): raise GateError(f"CSV_HEADER_MISSING:{sorted(need-set(idx))}")
        source=reader
    else:
        idx={"open_time":0,"open":1,"high":2,"low":3,"close":4,"volume":5}
        source=iter([first]+list(reader))
    for row in source:
        if len(row)<=max(idx.values()): continue
        try:
            yield {
                "open_time":int(float(row[idx["open_time"]])),
                "open":float(row[idx["open"]]),"high":float(row[idx["high"]]),
                "low":float(row[idx["low"]]),"close":float(row[idx["close"]]),
                "volume":float(row[idx["volume"]])
            }
        except (ValueError,TypeError): continue

def build_daily(files):
    per=defaultdict(dict); inventory=[]
    for symbol,path in files:
        seen=used=skip2025=0; min_ts=max_ts=None
        for stream in _streams(path):
            for r in _rows(stream):
                seen+=1; ts=r["open_time"]
                if ts>=BLOCK_2026_MS:
                    raise GateError(f"HARD_BLOCK_2026_PLUS:{path}:{ts}")
                min_ts=ts if min_ts is None else min(min_ts,ts)
                max_ts=ts if max_ts is None else max(max_ts,ts)
                if ts>=DISCOVERY_AFTER_MS:
                    skip2025+=1
                    continue
                if ts<DISCOVERY_FIRST_MS: continue
                used+=1
                dt=datetime.fromtimestamp(ts/1000,tz=timezone.utc)
                day=dt.date().isoformat()
                minute=dt.hour*60+dt.minute
                d=per[symbol].get(day)
                if d is None:
                    d={"date":day,"open":r["open"],"high":r["high"],"low":r["low"],"close":r["close"],
                       "volume":r["volume"],"first_ts":ts,"last_ts":ts,"mask":0,"duplicates":0,
                       "open_0001":None}
                    per[symbol][day]=d
                bit=1<<minute
                if d["mask"] & bit: d["duplicates"]+=1
                else: d["mask"] |= bit
                if ts<d["first_ts"]: d["first_ts"]=ts; d["open"]=r["open"]
                if ts>=d["last_ts"]: d["last_ts"]=ts; d["close"]=r["close"]
                d["high"]=max(d["high"],r["high"]); d["low"]=min(d["low"],r["low"]); d["volume"]+=r["volume"]
                if minute==1: d["open_0001"]=r["open"]
        inventory.append({"symbol":symbol,"file":str(path),"rows_seen":seen,"rows_used_discovery":used,
                          "rows_skipped_2025":skip2025,"min_open_time":min_ts,"max_open_time":max_ts})
    bars={}
    integrity={}
    for s,dm in per.items():
        arr=[]; integ=[]
        for day in sorted(dm):
            d=dm[day]
            minutes=d["mask"].bit_count()
            valid=(minutes==1440 and d["duplicates"]==0)
            item={k:v for k,v in d.items() if k!="mask"}
            item["minutes"]=minutes; item["valid_day"]=valid
            arr.append(item)
            integ.append({"date":day,"minutes":minutes,"duplicates":d["duplicates"],
                          "has_0001_open":d["open_0001"] is not None,"valid_day":valid})
        bars[s]=arr; integrity[s]=integ
    return bars,integrity,inventory
