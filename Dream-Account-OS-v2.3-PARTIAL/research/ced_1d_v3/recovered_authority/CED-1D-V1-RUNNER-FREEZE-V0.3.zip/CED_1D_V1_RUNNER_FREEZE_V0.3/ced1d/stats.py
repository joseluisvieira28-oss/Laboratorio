import math,statistics
def raw_summary(vals):
    a=[float(x) for x in vals if x is not None and math.isfinite(float(x))]
    if not a:return {"n":0,"mean_bps":None,"median_bps":None,"win_rate":None,"stdev_bps":None}
    return {"n":len(a),"mean_bps":sum(a)/len(a)*10000,
            "median_bps":statistics.median(a)*10000,
            "win_rate":sum(x>0 for x in a)/len(a),
            "stdev_bps":statistics.stdev(a)*10000 if len(a)>1 else 0.0}
