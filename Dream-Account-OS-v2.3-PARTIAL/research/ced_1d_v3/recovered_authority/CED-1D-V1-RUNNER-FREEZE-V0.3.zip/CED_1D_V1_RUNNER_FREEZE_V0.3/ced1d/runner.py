import csv,json
from pathlib import Path
from .guards import load_authority,GateError
from .data import files_from_research_index,build_daily
from .hypotheses import primary_registry,family_e_blocked_registry,generate_events
from .fingerprint import write_json,sha256_json
from .stats import raw_summary

def preflight(authority_dir,dataset_workspace,input_index):
    auth=load_authority(authority_dir)
    root=Path(dataset_workspace)
    if not root.exists():raise GateError("DATASET_WORKSPACE_NOT_FOUND")
    files=files_from_research_index(root,input_index,auth["symbols"])
    return {"status":"PREFLIGHT_PASS","symbols":auth["symbols"],
            "contract_sha256":auth["contract_sha256"],
            "phase2_dataset_fingerprint":auth["dataset_fingerprint"],
            "discovery_files_resolved":len(files),
            "discovery_months_per_symbol":48,
            "confirmation_2025_files_opened":0,
            "input_mode":"RESEARCH_INPUT_INDEX"}

def raw_discovery(authority_dir,dataset_workspace,input_index,output_dir):
    auth=load_authority(authority_dir)
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    files4=files_from_research_index(dataset_workspace,input_index,auth["symbols"])
    files=[(symbol,path) for symbol,path,month,source_type in files4]

    bars,integrity,inventory=build_daily(files)
    write_json(out/"dataset_inventory.json",inventory)
    write_json(out/"daily_integrity.json",integrity)
    fp=sha256_json({s:bars.get(s,[]) for s in sorted(auth["symbols"])})
    write_json(out/"derived_daily_fingerprint.json",{"sha256":fp,
        "valid_day_counts":{s:sum(1 for b in bars.get(s,[]) if b["valid_day"]) for s in auth["symbols"]}})

    regs=primary_registry(auth["symbols"])
    if len(regs)!=820:raise GateError(f"PRIMARY_REGISTRY_DRIFT:{len(regs)}")
    e=family_e_blocked_registry()
    if len(e)!=16:raise GateError(f"FAMILY_E_DESIGN_REGISTRY_DRIFT:{len(e)}")
    write_json(out/"primary_atomic_registry.json",regs)
    write_json(out/"family_e_blocked_registry.json",e)

    ef=out/"event_ledger.csv"; rf=out/"results_raw.csv"
    with ef.open("w",newline="",encoding="utf-8") as efile,rf.open("w",newline="",encoding="utf-8") as rfile:
        ew=csv.DictWriter(efile,fieldnames=["test_id","family","symbol","signal_day","status","entry_day",
            "exit_day","direction","entry_open","exit_open","raw_return","signed_return"])
        rw=csv.DictWriter(rfile,fieldnames=["test_id","family","symbol","config_json","trade_count",
            "data_unavailable_count","overlap_blocked_count","mean_bps","median_bps","win_rate","stdev_bps",
            "classification"])
        ew.writeheader();rw.writeheader()
        for i,cfg in enumerate(regs,1):
            tid=f"CED1D-{i:04d}"; vals=[]; du=ob=tr=0
            for ev in generate_events(bars.get(cfg["symbol"],[]),cfg):
                status=ev["status"]
                if status=="TRADE":tr+=1;vals.append(ev["signed_return"])
                elif status=="DATA_UNAVAILABLE":du+=1
                elif status=="OVERLAP_BLOCKED":ob+=1
                ew.writerow({"test_id":tid,"family":cfg["family"],"symbol":cfg["symbol"],
                    "signal_day":ev.get("signal_day"),"status":status,"entry_day":ev.get("entry_day"),
                    "exit_day":ev.get("exit_day"),"direction":ev.get("direction"),
                    "entry_open":ev.get("entry_open"),"exit_open":ev.get("exit_open"),
                    "raw_return":ev.get("raw_return"),"signed_return":ev.get("signed_return")})
            sm=raw_summary(vals)
            rw.writerow({"test_id":tid,"family":cfg["family"],"symbol":cfg["symbol"],
                "config_json":json.dumps(cfg,sort_keys=True,separators=(",",":")),
                "trade_count":tr,"data_unavailable_count":du,"overlap_blocked_count":ob,
                "mean_bps":sm["mean_bps"],"median_bps":sm["median_bps"],"win_rate":sm["win_rate"],
                "stdev_bps":sm["stdev_bps"],
                "classification":"NOT_PERFORMED_PENDING_CANONICAL_V0.2_NUMERIC_GOVERNANCE"})

    manifest={"lab":"CED-1D-V1","stage":"RAW_DISCOVERY_LEDGER_ONLY","runner_version":"0.3.0",
        "input_mode":"RESEARCH_INPUT_INDEX","discovery_source_slots":480,
        "primary_tests":820,"family_e_executable":False,"family_e_design_cells":16,
        "discovery":"2021-01-01/2024-12-31","confirmation_2025_accessed":False,
        "confirmation_2025_files_opened":0,"final_holdout":"UNASSIGNED_LOCKED_FUTURE",
        "access_2026_plus":False,"contract_sha256":auth["contract_sha256"],
        "phase2_dataset_fingerprint":auth["dataset_fingerprint"],"derived_daily_sha256":fp,
        "costs_applied":False,"multiple_testing_applied":False,"scout_score_applied":False,
        "closeout_status":"BLOCKED_PENDING_CANONICAL_V0.2_NUMERIC_GOVERNANCE_MAPPING"}
    write_json(out/"run_manifest.json",manifest)
    return manifest
