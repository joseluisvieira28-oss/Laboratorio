from itertools import product
from datetime import date,timedelta
import math

A_H=[1,3,5,10,20]
CD_H=[1,3,5,10]
DIRS=["CONTINUATION","REVERSAL"]

def primary_registry(symbols):
    out=[]
    for s,lb,h,d in product(symbols,[20,60,120],A_H,DIRS):
        out.append({"family":"A_MOMENTUM","symbol":s,"lookback":lb,"horizon":h,"direction":d})
    for s,lb,h,d in product(symbols,[20,60],A_H,DIRS):
        out.append({"family":"B_BREAKOUT","symbol":s,"lookback":lb,"horizon":h,"direction":d})
    for s,tail,h,d in product(symbols,[0.90,0.95],CD_H,DIRS):
        out.append({"family":"C_EXTREME_SHOCK","symbol":s,"tail":tail,"history":365,"horizon":h,"direction":d})
    for s,state,h,d in product(symbols,["COMPRESSION","EXPANSION"],CD_H,DIRS):
        out.append({"family":"D_VOL_REGIME","symbol":s,"rv_lookback":20,"history":365,
                    "state":state,"compression_q":0.20,"expansion_q":0.80,
                    "horizon":h,"direction":d})
    return out

def family_e_blocked_registry():
    return [{"family":"E_XS_REL_STRENGTH","lookback":lb,"horizon":h,"direction":d,
             "status":"DESIGN_FROZEN_EXECUTION_BLOCKED"}
            for lb,h,d in product([20,60],CD_H,DIRS)]

def qtile(vals,q):
    a=sorted(v for v in vals if v is not None and math.isfinite(v))
    if not a:return None
    if len(a)==1:return a[0]
    x=(len(a)-1)*q; lo=int(math.floor(x)); hi=int(math.ceil(x))
    if lo==hi:return a[lo]
    w=x-lo; return a[lo]*(1-w)+a[hi]*w

def sgn(x): return 1 if x>0 else -1 if x<0 else 0
def logret(a,b): return math.log(b/a) if a>0 and b>0 else None

class Series:
    def __init__(self,bars):
        self.by={b["date"]:b for b in bars}
        self.dates=sorted(self.by)
        self.valid_dates=[d for d in self.dates if self.by[d]["valid_day"]]
        self.valid_pos={d:i for i,d in enumerate(self.valid_dates)}

    def valid_bar(self,d):
        b=self.by.get(d)
        return b if b and b["valid_day"] else None

    def prior_valid_dates(self,d,n):
        i=self.valid_pos.get(d)
        if i is None or i<n:return None
        return self.valid_dates[i-n:i]

    def log_return_valid_lookback(self,d,n):
        i=self.valid_pos.get(d)
        if i is None or i<n:return None
        a=self.by[self.valid_dates[i-n]]["close"]; b=self.by[d]["close"]
        return logret(a,b)

    def execution(self,signal_day,horizon):
        sd=date.fromisoformat(signal_day)
        entry=(sd+timedelta(days=1)).isoformat()
        exitd=(sd+timedelta(days=1+horizon)).isoformat()
        # Conservative path rule: every calendar day in entry..exit must be locally valid.
        cur=sd+timedelta(days=1)
        end=sd+timedelta(days=1+horizon)
        while cur<=end:
            b=self.by.get(cur.isoformat())
            if not b or not b["valid_day"]:
                return None,"DATA_UNAVAILABLE"
            cur+=timedelta(days=1)
        eb=self.by[entry]; xb=self.by[exitd]
        if eb["open_0001"] is None or xb["open_0001"] is None:
            return None,"DATA_UNAVAILABLE"
        r=xb["open_0001"]/eb["open_0001"]-1
        return {"entry_day":entry,"exit_day":exitd,"entry_open":eb["open_0001"],
                "exit_open":xb["open_0001"],"raw_return":r},"OK"

    def completed_daily_log_returns(self):
        out={}
        vd=self.valid_dates
        for i in range(1,len(vd)):
            out[vd[i]]=logret(self.by[vd[i-1]]["close"],self.by[vd[i]]["close"])
        return out

    def rv20_map(self):
        rets=self.completed_daily_log_returns(); out={}
        vd=self.valid_dates
        for i,d in enumerate(vd):
            if i<20: continue
            window=vd[i-19:i+1]
            xs=[rets.get(x) for x in window]
            if any(x is None for x in xs): continue
            out[d]=math.sqrt(sum(x*x for x in xs))
        return out

def signal_for(series,cfg,d,cache):
    fam=cfg["family"]
    if fam=="A_MOMENTUM":
        x=series.log_return_valid_lookback(d,cfg["lookback"])
        if x is None:return None
        ref=sgn(x)
    elif fam=="B_BREAKOUT":
        b=series.valid_bar(d)
        prior=series.prior_valid_dates(d,cfg["lookback"])
        if not b or prior is None:return None
        highs=[series.by[x]["high"] for x in prior]; lows=[series.by[x]["low"] for x in prior]
        ref=1 if b["close"]>max(highs) else -1 if b["close"]<min(lows) else 0
    elif fam=="C_EXTREME_SHOCK":
        rets=cache["daily_rets"]
        if d not in rets:return None
        prior=series.prior_valid_dates(d,cfg["history"])
        if prior is None:return None
        vals=[rets.get(x) for x in prior if rets.get(x) is not None]
        if len(vals)<cfg["history"]-1:return None
        hi=qtile(vals,cfg["tail"]); lo=qtile(vals,1-cfg["tail"]); x=rets[d]
        ref=1 if x>=hi else -1 if x<=lo else 0
    elif fam=="D_VOL_REGIME":
        rv=cache["rv20"]
        cur=rv.get(d)
        if cur is None:return None
        prior=series.prior_valid_dates(d,cfg["history"])
        if prior is None:return None
        vals=[rv.get(x) for x in prior if rv.get(x) is not None]
        if len(vals)<cfg["history"]-20:return None
        lo=qtile(vals,cfg["compression_q"]); hi=qtile(vals,cfg["expansion_q"])
        state="COMPRESSION" if cur<=lo else "EXPANSION" if cur>=hi else None
        if state!=cfg["state"]:return None
        x=series.log_return_valid_lookback(d,20)
        if x is None:return None
        ref=sgn(x)
    else: raise ValueError(fam)
    if ref==0:return None
    return ref if cfg["direction"]=="CONTINUATION" else -ref

def generate_events(bars,cfg):
    series=Series(bars)
    cache={"daily_rets":series.completed_daily_log_returns(),"rv20":series.rv20_map()}
    active_exit=None
    for d in series.valid_dates:
        direction=signal_for(series,cfg,d,cache)
        if direction is None: continue
        ex,status=series.execution(d,cfg["horizon"])
        if status!="OK":
            yield {"signal_day":d,"status":"DATA_UNAVAILABLE"}
            continue
        entry=date.fromisoformat(ex["entry_day"]); exitd=date.fromisoformat(ex["exit_day"])
        if active_exit is not None and entry<active_exit:
            yield {"signal_day":d,"status":"OVERLAP_BLOCKED","entry_day":ex["entry_day"],"exit_day":ex["exit_day"]}
            continue
        active_exit=exitd
        yield {"signal_day":d,"status":"TRADE","direction":direction,**ex,
               "signed_return":direction*ex["raw_return"]}
