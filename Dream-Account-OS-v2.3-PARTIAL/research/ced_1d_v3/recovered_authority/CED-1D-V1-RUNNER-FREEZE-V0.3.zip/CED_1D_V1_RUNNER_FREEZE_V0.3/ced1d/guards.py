import json
from pathlib import Path
from .fingerprint import sha256_file

class GateError(RuntimeError): pass

def _json(path):
    p=Path(path)
    if not p.exists(): raise GateError(f"MISSING_REQUIRED_AUTHORITY_FILE:{p.name}")
    return json.loads(p.read_text(encoding="utf-8"))

def load_authority(authority_dir):
    p=Path(authority_dir)
    universe=_json(p/"CED-PH2-FROZEN-UNIVERSE.json")
    ca=_json(p/"contract_authority.json")
    evidence=_json(p/"phase2_dataset_evidence.json")
    contract=p/"contract.json"
    if not contract.exists(): raise GateError("MISSING_REQUIRED_AUTHORITY_FILE:contract.json")

    syms=universe.get("symbols")
    if universe.get("authority_status")!="RECOVERED_CANONICAL":
        raise GateError("UNIVERSE_NOT_RECOVERED_CANONICAL")
    if not isinstance(syms,list) or len(syms)!=10 or len(set(syms))!=10:
        raise GateError("UNIVERSE_MUST_BE_EXACTLY_10_UNIQUE_SYMBOLS")

    if ca.get("authority_status")!="VERIFIED_CANONICAL":
        raise GateError("CONTRACT_NOT_VERIFIED_CANONICAL")
    actual=sha256_file(contract)
    if ca.get("sha256")!=actual:
        raise GateError("CONTRACT_SHA256_MISMATCH")

    if evidence.get("verdict")!="DATASET_PASS":
        raise GateError("PHASE2_DATASET_NOT_PASS")
    if not evidence.get("dataset_fingerprint"):
        raise GateError("MISSING_DATASET_FINGERPRINT")
    if evidence.get("statistical_research_run") not in (False,"NO"):
        raise GateError("PHASE2_STATISTICAL_RESEARCH_MUST_BE_FALSE")
    if evidence.get("holdout_assigned") not in (False,"NO",None):
        raise GateError("FINAL_HOLDOUT_MUST_REMAIN_UNASSIGNED")

    return {
        "symbols":syms,
        "contract_sha256":actual,
        "dataset_fingerprint":evidence["dataset_fingerprint"],
    }
