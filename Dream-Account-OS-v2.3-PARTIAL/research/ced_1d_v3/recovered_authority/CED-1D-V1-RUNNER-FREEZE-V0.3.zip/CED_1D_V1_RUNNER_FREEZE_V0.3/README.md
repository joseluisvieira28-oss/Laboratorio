# CED-1D-V1 — Runner Freeze V0.3

Status: IMPLEMENTATION FROZEN / REAL DISCOVERY EXECUTION FAIL-CLOSED

V0.3 supersedes V0.2 for datasets using Phase 2 Data Repair Amendment 01.

## V0.3 change
The runner no longer recursively discovers all ZIPs in a dataset tree.
It requires a 600-slot `RESEARCH_INPUT_INDEX.json` and resolves exactly:
- 480 Discovery source months (10 symbols × 48 months, 2021-01..2024-12);
- exactly one canonical file per symbol/month;
- repaired composite files for amended cells;
- original monthly files for unaffected cells.

**2025 index entries are ignored before filesystem resolution.**
The runner therefore opens zero 2025 market files during 1D Discovery.

The canonical V0.2 contract authority gate remains mandatory and unresolved unless separately recovered.
V0.3 does not weaken that gate.


- Parent: CED — Crypto Edge Discovery Engine
- Child: CED-1D-V1
- Discovery: 2021-01-01 through 2024-12-31 UTC only
- 2025 Confirmation: LOCKED / NOT ACCESSED
- Final Holdout: UNASSIGNED / LOCKED-FUTURE
- 2026+: HARD BLOCK
- 4H and 1H: remain unopened until 1D Discovery closeout

## Exact primary campaign
A — Daily Momentum / Trend Persistence
- lookbacks 20D / 60D / 120D
- directions CONTINUATION / REVERSAL
- horizons 1D / 3D / 5D / 10D / 20D
- 10 assets
- 300 tests

B — Daily Range Breakout / Failure
- prior ranges 20D / 60D
- directions CONTINUATION / REVERSAL
- horizons 1D / 3D / 5D / 10D / 20D
- 10 assets
- 200 tests

C — Extreme Daily Shock Response
- current completed daily LOG return
- causal ranking against prior 365 completed valid daily returns
- tails 90/10 and 95/5
- directions CONTINUATION / REVERSAL
- horizons 1D / 3D / 5D / 10D
- 10 assets
- 160 tests

D — Daily Volatility Regime Interaction
- RV20 = sqrt(sum squared completed daily log returns over prior 20 valid days)
- causal RV20 percentile vs prior 365 completed valid RV20 observations
- COMPRESSION <=20th percentile
- EXPANSION >=80th percentile
- reference direction = sign prior 20D completed-day log return
- directions CONTINUATION / REVERSAL
- horizons 1D / 3D / 5D / 10D
- 10 assets
- 160 tests

PRIMARY EXECUTABLE BUDGET = 820.

E — Daily Cross-Sectional Relative Strength
- lookbacks 20D / 60D
- directions CONTINUATION / REVERSAL
- horizons 1D / 3D / 5D / 10D
- DESIGN FROZEN / EXECUTION BLOCKED.
- Portfolio construction, minimum eligible universe and concentration rules are NOT invented here.

## Causal execution
Signal uses only completed daily information through signal day D.
- Signal boundary: end of D at 00:00 UTC of D+1
- Entry: exact 1m open at D+1 00:01 UTC
- Exit: exact 1m open horizon calendar-days after entry
- no nearest-neighbour
- missing exact entry/exit/path => DATA_UNAVAILABLE
- one active event per asset/config until exit
- later qualifying signals before exit => OVERLAP_BLOCKED

## Local daily integrity layer
The runner derives daily candles from canonical 1m data and locally requires:
- 1440 unique minutes per UTC day
- zero duplicate minutes
This does not replace the upstream CED Phase 2 DATASET_PASS; it is an additional conservative execution guard.

## Required authority files
No real Discovery run is allowed unless all are present:
- `CED-PH2-FROZEN-UNIVERSE.json`
  - exactly 10 unique symbols
  - authority_status = RECOVERED_CANONICAL
- `contract.json`
  - canonical CED Phase 1 V0.2 bytes
- `contract_authority.json`
  - authority_status = VERIFIED_CANONICAL
  - sha256 = exact hash of contract.json
- `phase2_dataset_evidence.json`
  - verdict = DATASET_PASS
  - dataset_fingerprint non-empty
  - statistical_research_run = false
  - holdout_assigned = false

The runner does NOT reconstruct missing V0.2 numeric governance.

## Two-stage use
1. Preflight:
   `python run_1d_lab.py --authority AUTHORITY_DIR --dataset DATASET_ROOT --output OUT`

2. Raw Discovery ledger, only after all authority gates pass:
   `python run_1d_lab.py --authority AUTHORITY_DIR --dataset DATASET_ROOT --output OUT --raw-discovery`

`--raw-discovery` produces gross causal event/results ledgers but DOES NOT apply guessed costs,
sample thresholds, multiple-testing, Scout score, shortlist thresholds or final classification.
Those closeout layers remain blocked until the canonical V0.2 contract is recovered and mapped without override.

## Dataset support
Reads `.csv` or `.zip` files containing Binance-style 1m kline CSV rows.
Raw Binance 12-column rows and common named headers are supported.

## Outputs
- preflight.json
- dataset_inventory.json
- daily_integrity.json
- derived_daily_fingerprint.json
- primary_atomic_registry.json (820)
- family_e_blocked_registry.json (16 design cells)
- event_ledger.csv
- results_raw.csv
- run_manifest.json

No live trading or order capability exists.
