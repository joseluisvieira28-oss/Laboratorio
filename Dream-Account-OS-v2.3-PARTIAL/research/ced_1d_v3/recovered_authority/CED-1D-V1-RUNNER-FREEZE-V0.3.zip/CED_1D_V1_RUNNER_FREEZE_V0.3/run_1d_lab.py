import argparse,json,sys
from pathlib import Path
from ced1d.runner import preflight,raw_discovery
from ced1d.guards import GateError
from ced1d.fingerprint import write_json

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--authority",required=True)
    p.add_argument("--dataset-workspace",required=True)
    p.add_argument("--input-index",default="REPAIR_A01/EVIDENCE/RESEARCH_INPUT_INDEX.json")
    p.add_argument("--output",default="CED1D_OUTPUT")
    p.add_argument("--raw-discovery",action="store_true")
    a=p.parse_args();out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    try:
        pf=preflight(a.authority,a.dataset_workspace,a.input_index);write_json(out/"preflight.json",pf)
        print(json.dumps(pf,indent=2))
        if not a.raw_discovery:
            print("PREFLIGHT ONLY — no market statistics executed.")
            return 0
        m=raw_discovery(a.authority,a.dataset_workspace,a.input_index,a.output)
        print(json.dumps(m,indent=2));return 0
    except GateError as e:
        err={"status":"FAIL_CLOSED","error":str(e)}
        write_json(out/"preflight.json",err)
        print(json.dumps(err,indent=2),file=sys.stderr);return 2
if __name__=="__main__":raise SystemExit(main())
