SHAPE EXAMPLES ONLY. DO NOT FABRICATE AUTHORITY.
Real execution requires recovered canonical files and exact hashes.
