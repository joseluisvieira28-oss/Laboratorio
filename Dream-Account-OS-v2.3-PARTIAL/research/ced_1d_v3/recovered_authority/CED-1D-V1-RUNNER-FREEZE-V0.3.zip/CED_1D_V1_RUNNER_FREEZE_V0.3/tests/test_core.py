import unittest,tempfile,json,csv,zipfile,math
from pathlib import Path
from datetime import date,timedelta
from ced1d.hypotheses import primary_registry,family_e_blocked_registry,qtile,sgn,logret,Series,generate_events
from ced1d.guards import load_authority,GateError
from ced1d.fingerprint import sha256_file,sha256_json
from ced1d.data import build_daily,discover_market_files
from ced1d.stats import raw_summary

def mkbar(day,close,valid=True,op=None):
    return {"date":day,"open":close,"high":close,"low":close,"close":close,"volume":1,
            "duplicates":0,"open_0001":close if op is None else op,"minutes":1440 if valid else 1439,
            "valid_day":valid}

def seqbars(start,n,fn=lambda i:100+i):
    d=date.fromisoformat(start);return [mkbar((d+timedelta(days=i)).isoformat(),fn(i)) for i in range(n)]

class T(unittest.TestCase):
    def test_primary_total(self):
        self.assertEqual(len(primary_registry([f"S{i}" for i in range(10)])),820)
    def test_counts(self):
        from collections import Counter
        c=Counter(x["family"] for x in primary_registry([f"S{i}" for i in range(10)]))
        self.assertEqual(c["A_MOMENTUM"],300);self.assertEqual(c["B_BREAKOUT"],200)
        self.assertEqual(c["C_EXTREME_SHOCK"],160);self.assertEqual(c["D_VOL_REGIME"],160)
    def test_e_blocked_16(self):self.assertEqual(len(family_e_blocked_registry()),16)
    def test_e_no_portfolio_invention(self):
        for x in family_e_blocked_registry():
            self.assertNotIn("top_n",x);self.assertNotIn("bottom_n",x)
    def test_c_history(self):
        self.assertTrue(all(x["history"]==365 for x in primary_registry(["X"]*10) if x["family"]=="C_EXTREME_SHOCK"))
    def test_d_history(self):
        self.assertTrue(all(x["history"]==365 for x in primary_registry(["X"]*10) if x["family"]=="D_VOL_REGIME"))
    def test_c_horizons(self):
        hs={x["horizon"] for x in primary_registry([f"S{i}" for i in range(10)]) if x["family"]=="C_EXTREME_SHOCK"}
        self.assertEqual(hs,{1,3,5,10})
    def test_d_horizons(self):
        hs={x["horizon"] for x in primary_registry([f"S{i}" for i in range(10)]) if x["family"]=="D_VOL_REGIME"}
        self.assertEqual(hs,{1,3,5,10})
    def test_qtile(self):self.assertEqual(qtile([1,2,3,4],.5),2.5)
    def test_sign(self):self.assertEqual((sgn(1),sgn(-1),sgn(0)),(1,-1,0))
    def test_logret(self):self.assertAlmostEqual(logret(100,110),math.log(1.1))
    def test_exec_exact_0001(self):
        b=seqbars("2021-01-01",5);s=Series(b)
        ex,st=s.execution("2021-01-01",1)
        self.assertEqual(st,"OK");self.assertEqual(ex["entry_day"],"2021-01-02");self.assertEqual(ex["exit_day"],"2021-01-03")
    def test_exec_missing_path(self):
        b=seqbars("2021-01-01",5);b[2]["valid_day"]=False;s=Series(b)
        ex,st=s.execution("2021-01-01",2);self.assertEqual(st,"DATA_UNAVAILABLE")
    def test_exec_missing_0001(self):
        b=seqbars("2021-01-01",4);b[1]["open_0001"]=None;s=Series(b)
        self.assertEqual(s.execution("2021-01-01",1)[1],"DATA_UNAVAILABLE")
    def test_overlap_blocking(self):
        b=seqbars("2021-01-01",40)
        cfg={"family":"A_MOMENTUM","lookback":20,"horizon":5,"direction":"CONTINUATION"}
        ev=list(generate_events(b,cfg))
        self.assertTrue(any(x["status"]=="OVERLAP_BLOCKED" for x in ev))
    def test_trades_exist_momentum(self):
        b=seqbars("2021-01-01",50)
        cfg={"family":"A_MOMENTUM","lookback":20,"horizon":1,"direction":"CONTINUATION"}
        self.assertTrue(any(x["status"]=="TRADE" for x in generate_events(b,cfg)))
    def test_reversal_negative_in_uptrend(self):
        b=seqbars("2021-01-01",50)
        cfg={"family":"A_MOMENTUM","lookback":20,"horizon":1,"direction":"REVERSAL"}
        vals=[x["signed_return"] for x in generate_events(b,cfg) if x["status"]=="TRADE"]
        self.assertTrue(vals and all(x<0 for x in vals))
    def test_stats(self):
        s=raw_summary([.01,-.01,.02]);self.assertEqual(s["n"],3)
    def test_json_hash_stable(self):self.assertEqual(sha256_json({"a":1,"b":2}),sha256_json({"b":2,"a":1}))
    def test_auth_missing(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(GateError):load_authority(d)
    def test_auth_valid(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);sy=[f"S{i}" for i in range(10)]
            (p/"CED-PH2-FROZEN-UNIVERSE.json").write_text(json.dumps({"authority_status":"RECOVERED_CANONICAL","symbols":sy}))
            (p/"contract.json").write_text('{"x":1}');sha=sha256_file(p/"contract.json")
            (p/"contract_authority.json").write_text(json.dumps({"authority_status":"VERIFIED_CANONICAL","sha256":sha}))
            (p/"phase2_dataset_evidence.json").write_text(json.dumps({"verdict":"DATASET_PASS","dataset_fingerprint":"fp","statistical_research_run":False,"holdout_assigned":False}))
            self.assertEqual(load_authority(p)["symbols"],sy)
    def test_auth_bad_sha(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);sy=[f"S{i}" for i in range(10)]
            (p/"CED-PH2-FROZEN-UNIVERSE.json").write_text(json.dumps({"authority_status":"RECOVERED_CANONICAL","symbols":sy}))
            (p/"contract.json").write_text('{}')
            (p/"contract_authority.json").write_text(json.dumps({"authority_status":"VERIFIED_CANONICAL","sha256":"bad"}))
            (p/"phase2_dataset_evidence.json").write_text(json.dumps({"verdict":"DATASET_PASS","dataset_fingerprint":"fp","statistical_research_run":False,"holdout_assigned":False}))
            with self.assertRaises(GateError):load_authority(p)
    def test_discover(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/"BTCUSDT-x.csv").write_text("")
            self.assertEqual(len(discover_market_files(p,["BTCUSDT"])),1)
    def test_raw_2025_skipped(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"BTCUSDT.csv"
            with p.open("w",newline="") as f:csv.writer(f).writerow([1735689600000,1,1,1,1,1,0,0,0,0,0,0])
            bars,integ,inv=build_daily([("BTCUSDT",p)])
            self.assertEqual(bars.get("BTCUSDT",[]),[]);self.assertEqual(inv[0]["rows_skipped_2025"],1)
    def test_2026_block(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"BTCUSDT.csv"
            with p.open("w",newline="") as f:csv.writer(f).writerow([1767225600000,1,1,1,1,1,0,0,0,0,0,0])
            with self.assertRaises(GateError):build_daily([("BTCUSDT",p)])
    def test_day_minute_bitset_and_0001(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"BTCUSDT.csv"
            base=1609459200000
            with p.open("w",newline="") as f:
                wr=csv.writer(f)
                for m in range(1440):
                    px=100+m/10000
                    wr.writerow([base+m*60000,px,px,px,px,1,0,0,0,0,0,0])
            bars,integ,inv=build_daily([("BTCUSDT",p)])
            self.assertTrue(bars["BTCUSDT"][0]["valid_day"])
            self.assertAlmostEqual(bars["BTCUSDT"][0]["open_0001"],100.0001)
    def test_duplicate_invalidates_day(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"BTCUSDT.csv";base=1609459200000
            with p.open("w",newline="") as f:
                wr=csv.writer(f)
                for m in range(1440):wr.writerow([base+m*60000,1,1,1,1,1,0,0,0,0,0,0])
                wr.writerow([base+60000,1,1,1,1,1,0,0,0,0,0,0])
            bars,_,_=build_daily([("BTCUSDT",p)])
            self.assertFalse(bars["BTCUSDT"][0]["valid_day"])
    def test_missing_minute_invalidates_day(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"BTCUSDT.csv";base=1609459200000
            with p.open("w",newline="") as f:
                wr=csv.writer(f)
                for m in range(1439):wr.writerow([base+m*60000,1,1,1,1,1,0,0,0,0,0,0])
            bars,_,_=build_daily([("BTCUSDT",p)])
            self.assertFalse(bars["BTCUSDT"][0]["valid_day"])
    def test_zip(self):
        with tempfile.TemporaryDirectory() as d:
            zp=Path(d)/"BTCUSDT.zip"
            with zipfile.ZipFile(zp,"w") as z:z.writestr("x.csv","1609459200000,1,1,1,1,1,0,0,0,0,0,0\n")
            bars,_,_=build_daily([("BTCUSDT",zp)]);self.assertEqual(len(bars["BTCUSDT"]),1)

if __name__=="__main__":unittest.main()
