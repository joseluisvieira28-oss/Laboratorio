import unittest,tempfile,json
from pathlib import Path
from ced1d.data import files_from_research_index
from ced1d.guards import GateError

class T(unittest.TestCase):
    def make_index(self,root,make_2025_files=False):
        rows=[]
        syms=[f"S{i}" for i in range(10)]
        for s in syms:
            for year in range(2021,2026):
                for month in range(1,13):
                    ym=f"{year}-{month:02d}"
                    rel=Path("RAW")/s/f"{s}-1m-{ym}.zip"
                    if year<=2024 or make_2025_files:
                        p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b"x")
                    rows.append({"symbol":s,"month":ym,"classification":"PASS",
                                 "relative_source_path":str(rel),"source_type":"TEST"})
        (root/"RESEARCH_INPUT_INDEX.json").write_text(json.dumps(rows))
        return syms
    def test_resolves_480_only(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);syms=self.make_index(root,make_2025_files=False)
            files=files_from_research_index(root,"RESEARCH_INPUT_INDEX.json",syms)
            self.assertEqual(len(files),480)
    def test_does_not_require_2025_files(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);syms=self.make_index(root,make_2025_files=False)
            files=files_from_research_index(root,"RESEARCH_INPUT_INDEX.json",syms)
            self.assertTrue(all(month<="2024-12" for _,_,month,_ in files))
    def test_requires_600_slots(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);(root/"RESEARCH_INPUT_INDEX.json").write_text("[]")
            with self.assertRaises(GateError):files_from_research_index(root,"RESEARCH_INPUT_INDEX.json",["S0"])
    def test_duplicate_slot_fails(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);syms=self.make_index(root,False)
            rows=json.loads((root/"RESEARCH_INPUT_INDEX.json").read_text())
            rows[-1]=dict(rows[0])
            (root/"RESEARCH_INPUT_INDEX.json").write_text(json.dumps(rows))
            with self.assertRaises(GateError):files_from_research_index(root,"RESEARCH_INPUT_INDEX.json",syms)
    def test_non_pass_slot_fails_even_2025(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);syms=self.make_index(root,False)
            rows=json.loads((root/"RESEARCH_INPUT_INDEX.json").read_text())
            rows[-1]["classification"]="REVIEW_REQUIRED"
            (root/"RESEARCH_INPUT_INDEX.json").write_text(json.dumps(rows))
            with self.assertRaises(GateError):files_from_research_index(root,"RESEARCH_INPUT_INDEX.json",syms)
    def test_missing_discovery_file_fails(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);syms=self.make_index(root,False)
            p=next((root/"RAW"/"S0").glob("*2021-01.zip"));p.unlink()
            with self.assertRaises(GateError):files_from_research_index(root,"RESEARCH_INPUT_INDEX.json",syms)
    def test_per_symbol_48(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);syms=self.make_index(root,False)
            files=files_from_research_index(root,"RESEARCH_INPUT_INDEX.json",syms)
            from collections import Counter
            c=Counter(s for s,_,_,_ in files)
            self.assertTrue(all(v==48 for v in c.values()))
if __name__=="__main__":unittest.main()
