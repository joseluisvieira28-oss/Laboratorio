#!/usr/bin/env bash
set -euo pipefail
[ "$#" -ge 2 ] || { echo "Usage: bash run_preflight.sh AUTHORITY_DIR DATASET_WORKSPACE"; exit 2; }
python3 run_1d_lab.py --authority "$1" --dataset-workspace "$2" --output CED1D_OUTPUT
