from collections import Counter
from ced1d.hypotheses import primary_registry,family_e_blocked_registry
syms=[f"SYM{i}" for i in range(10)]
r=primary_registry(syms);c=Counter(x["family"] for x in r)
print("PRIMARY_TOTAL",len(r))
for k,v in sorted(c.items()):print(k,v)
print("FAMILY_E_BLOCKED_DESIGN_CELLS",len(family_e_blocked_registry()))
