@echo off
setlocal
if "%~2"=="" (
 echo Usage: run_preflight.bat AUTHORITY_DIR DATASET_WORKSPACE
 exit /b 2
)
where py >nul 2>nul
if %errorlevel%==0 (
 py -3 run_1d_lab.py --authority "%~1" --dataset-workspace "%~2" --output "CED1D_OUTPUT"
 exit /b %errorlevel%
)
where python >nul 2>nul
if %errorlevel%==0 (
 python run_1d_lab.py --authority "%~1" --dataset-workspace "%~2" --output "CED1D_OUTPUT"
 exit /b %errorlevel%
)
echo Python 3 not found.
exit /b 3
